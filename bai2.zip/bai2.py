import math

print("===== MENU =====")
print("1. Kiểm tra chia hết cho 2 và 3")
print("2. Giải phương trình bậc 2")

choice = int(input("Chọn bài (1 hoặc 2): "))

# ======================
# BÀI 4
# ======================
if choice == 1:
    n = int(input("Nhập số nguyên dương: "))

    if n % 2 == 0 and n % 3 == 0:
        print("Số chia hết cho cả 2 và 3")
    elif n % 2 == 0:
        print("Số chia hết cho 2")
    elif n % 3 == 0:
        print("Số chia hết cho 3")
    else:
        print("Số không chia hết cho 2 và 3")

# ======================
# BÀI 5
# ======================
elif choice == 2:
    a = float(input("Nhập a: "))
    b = float(input("Nhập b: "))
    c = float(input("Nhập c: "))

    if a == 0:
        if b == 0:
            if c == 0:
                print("Phương trình vô số nghiệm")
            else:
                print("Phương trình vô nghiệm")
        else:
            x = -c / b
            print("Nghiệm x =", x)
    else:
        delta = b**2 - 4*a*c

        if delta > 0:
            x1 = (-b + math.sqrt(delta)) / (2*a)
            x2 = (-b - math.sqrt(delta)) / (2*a)
            print("2 nghiệm:")
            print("x1 =", x1)
            print("x2 =", x2)
        elif delta == 0:
            x = -b / (2*a)
            print("Nghiệm kép x =", x)
        else:
            print("Phương trình vô nghiệm")

else:
    print("Lựa chọn không hợp lệ!")